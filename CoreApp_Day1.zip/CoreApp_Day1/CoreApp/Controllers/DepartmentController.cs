﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using CoreApp.Models;
using CoreApp.Services;

namespace CoreApp.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly IService<Department, int> _service;

        public DepartmentController(IService<Department, int> service)
        {
            _service = service;
        }
        public IActionResult Index()
        {
            var data = _service.GetAsync().Result;
            return View(data);
        }

        public IActionResult Create()
        {
            var data = new Department();
            return View(data);
        }

        [HttpPost]
        public IActionResult Create(Department data)
        {
            if (ModelState.IsValid)
            {
                data = _service.CreateAsync(data).Result;
                return RedirectToAction("Index");
            }
            else
            {
                return View(data);
            }
        }

        public IActionResult Edit(int id)
        {
            var data = _service.GetAsync(id).Result;
            return View(data);
        }

        [HttpPost]
        public IActionResult Edit(int id, Department data)
        {
            if (ModelState.IsValid)
            {
                data = _service.UpdateAsync(id, data).Result;
                return RedirectToAction("Index");
            }
            else
            {
                return View(data);
            }
        }

        public IActionResult Delete(int id)
        {
            var data = _service.DeleteAsync(id).Result;
            return RedirectToAction("Index");
        }

    }
}